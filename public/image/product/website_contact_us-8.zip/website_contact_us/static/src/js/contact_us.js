$(document).ready(function () {
    $(window, document, undefined).ready(function() {
        $('input').blur(function() {
          var $this = $(this);
          if ($this.val())
            $this.addClass('used');
          else
            $this.removeClass('used');
        });
      });
});
